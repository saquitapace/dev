export * from './app/app.component';
export * from './header/header.component';
export * from './footer/footer.component';
export * from './main/main.component';
export * from './report/report.component';
export * from './report-action/report-action.component';
export * from './report-detail-dialog/report-detail-dialog.component';