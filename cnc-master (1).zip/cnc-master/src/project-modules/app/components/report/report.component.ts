import { Component, ViewChild, OnInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { MatDialog } from '@angular/material/dialog';

import { AppService } from "../../services";
import { ReportDetailDialogComponent } from "./../report-detail-dialog/report-detail-dialog.component";

@Component({
  selector: 'app-report',
  templateUrl: './report.component.html',
  styleUrls: ['./report.component.scss']
})
export class ReportComponent implements OnInit {

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  public radioOption: string = 'vmi';
  public selectOption1: number;
  public selectOption2: number;
  public selectOption3: number;
  public selectOption4: number;
  public startRow: number = 655;
  public figItem: number = 100;
  public itemPN: number = 142;
  public pNText: number = 242;
  public textEFF: number = 478;
  public eFFQty: number = 521;
  public endRow: number = 79;

  public selects: any[] = [
    { title: 'Select One', value: 1 },
    { title: 'Select Two', value: 3 },
    { title: 'Select Three', value: 3 },
  ];

  private staticImportedPDFData: any[] = [
    { pageNumber: 1, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 1 },
    { pageNumber: 2, fig: 2, items: 2, partNumber: 2, text: 2, eff: 2, qty: 2 },
    { pageNumber: 3, fig: 3, items: 3, partNumber: 3, text: 3, eff: 3, qty: 3 },
    { pageNumber: 4, fig: 4, items: 4, partNumber: 4, text: 4, eff: 4, qty: 4 },
    { pageNumber: 5, fig: 5, items: 5, partNumber: 5, text: 5, eff: 5, qty: 5 },
    { pageNumber: 6, fig: 6, items: 6, partNumber: 6, text: 6, eff: 6, qty: 6 },
    { pageNumber: 7, fig: 7, items: 7, partNumber: 7, text: 7, eff: 7, qty: 7 },
    { pageNumber: 8, fig: 8, items: 8, partNumber: 8, text: 8, eff: 8, qty: 8 },
    { pageNumber: 111, fig: 111, items: 111, partNumber: 111, text: 111, eff: 111, qty: 111 },
    { pageNumber: 112, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 12112 },
    { pageNumber: 113, fig: 1, items: 1, partNumber: 1, text: 113, eff: 1, qty: 113 },
    { pageNumber: 114, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 114 },
    { pageNumber: 115, fig: 1, items: 1, partNumber: 15, text: 1, eff: 1, qty: 115 },
    { pageNumber: 116, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 116 },
    { pageNumber: 127, fig: 1, items: 271, partNumber: 1, text: 1, eff: 1, qty: 127 },
    { pageNumber: 129, fig: 1, items: 1, partNumber: 1, text: 29, eff: 1, qty: 129 },
    { pageNumber: 130, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 130 },
    { pageNumber: 133, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 133 },
    { pageNumber: 135, fig: 1, items: 1, partNumber: 1, text: 1, eff: 351, qty: 135 },
    { pageNumber: 137, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 137 },
    { pageNumber: 138, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 138 },
    { pageNumber: 139, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 139 },
    { pageNumber: 134, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 134 },
    { pageNumber: 145, fig: 1, items: 1, partNumber: 451, text: 1, eff: 1, qty: 145 },
    { pageNumber: 1464, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 1464 },
    { pageNumber: 157, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 571 },
    { pageNumber: 167, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 167 },
    { pageNumber: 178, fig: 1, items: 1, partNumber: 1, text: 1, eff: 1, qty: 178 }
  ];

  importedPDFDataColumns: string[] = ['pageNumber', 'fig', 'items', 'partNumber', 'text', 'eff', 'qty', 'action'];
  importedPDFDataSource: MatTableDataSource<any> = new MatTableDataSource([]);

  editAndValidateDataColumns: any[] = [];
  editAndValidateDataSource: MatTableDataSource<any> = new MatTableDataSource([]);

  saveConvertedDataColumns: string[] = [];
  saveConvertedDataSource: MatTableDataSource<any> = new MatTableDataSource([]);

  private dataFromJson: any[];
  private currentModalData: any;
  public loaded: boolean = false;

  constructor(public dialog: MatDialog, private appService: AppService) {
    this.appService.selectedModal$.subscribe((value: string) => {
      if (this.dataFromJson) {
        this.currentModalData = this.dataFromJson[value];

        /** Loading static data starts */
        this.importedPDFDataSource = new MatTableDataSource(this.staticImportedPDFData);
        this.importedPDFDataSource.paginator = this.paginator;
        this.importedPDFDataSource.sort = this.sort;
        /** Loading static data end */

        this.editAndValidateDataColumns = this.currentModalData.columns;
        this.editAndValidateDataSource = new MatTableDataSource(this.currentModalData.data);

        this.saveConvertedDataColumns = this.currentModalData.columns;
        this.saveConvertedDataSource = new MatTableDataSource(this.currentModalData.data);

      }
    })
  }

  ngOnInit() {
    this.importedPDFDataSource.paginator = this.paginator;
    this.importedPDFDataSource.sort = this.sort;

    this.appService.getData().subscribe((data: any[]) => {
      this.dataFromJson = data;
    }, error => console.log('error from service: ', error))

  }

  openDetailModal(row: any) {
    const dialogRef = this.dialog.open(ReportDetailDialogComponent, {
      width: '1000px',
      data: row
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  decreaseValue(key) {
    key -= 1;
  }
}
