import { Component } from '@angular/core';
import { MatSelectChange } from '@angular/material';
import { AppService } from "../../services";

@Component({
  selector: 'app-report-action',
  templateUrl: './report-action.component.html',
  styleUrls: ['./report-action.component.scss']
})
export class ReportActionComponent {
  public selects: any[] = [
    { title: 'C 737', value: "c737" },
    { title: 'C 738', value: "c738" },
    { title: 'C 739', value: "c739" },
  ];

  public selectOption1: number;
  public supplier: string = 'Jamco';
  public cmm: string = '122-13-22 Rev 012';
  public totalOfPages: number = 13;
  public ediPages: string;
  public iplPages: string;
  public artPages: string;

  constructor(private appService: AppService) { }

  public modalSelectionChange(event: MatSelectChange) {
    this.appService.updateSelectedModal(event.value);
  }
}
