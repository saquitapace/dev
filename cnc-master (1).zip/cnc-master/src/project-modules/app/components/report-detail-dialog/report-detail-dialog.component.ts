import { Component, Inject, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-report-detail-dialog',
  templateUrl: './report-detail-dialog.component.html',
  styleUrls: ['./report-detail-dialog.component.scss']
})
export class ReportDetailDialogComponent {

  displayedColumns: string[] = ['fig', 'item', 'discrepency'];
  dataSource: MatTableDataSource<any> = new MatTableDataSource([
    { fig: 'value', item: 'value', discrepency: 'value'},
    { fig: 'value', item: 'value', discrepency: 'value'},
    { fig: 'value', item: 'value', discrepency: 'value'},
    { fig: 'value', item: 'value', discrepency: 'value'},
  ]);

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  constructor(
    public dialogRef: MatDialogRef<ReportDetailDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { 
      console.log('data in dialog: ', this.data)
    }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
