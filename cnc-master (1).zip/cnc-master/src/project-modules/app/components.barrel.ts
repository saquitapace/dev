import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import {
    MatIconModule, MatMenuModule, MatButtonModule, MatCardModule, MatRadioModule, MatSelectModule, MatCheckboxModule,
    MatTabsModule, MatInputModule, MatFormFieldModule, MatTableModule, MatPaginatorModule, MatTooltipModule,
    MatDialogModule
} from "@angular/material";

import { AppService } from "./services";

import { AppComponent, HeaderComponent, FooterComponent, MainComponent, ReportComponent, ReportActionComponent, ReportDetailDialogComponent } from './components';
import { CustomMatTableCellDirective } from "./directives";

export const __IMPORTS = [
    BrowserModule, BrowserAnimationsModule, FormsModule, ReactiveFormsModule, HttpClientModule, FlexLayoutModule, MatIconModule, MatMenuModule,
    MatButtonModule, MatCardModule, MatRadioModule, MatSelectModule, MatCheckboxModule, MatTabsModule, MatInputModule, MatFormFieldModule,
    MatTableModule, MatPaginatorModule, MatTooltipModule, MatDialogModule
];

export const __DECLARATION = [
    AppComponent, HeaderComponent, FooterComponent, MainComponent, ReportComponent, ReportActionComponent, ReportDetailDialogComponent,
    CustomMatTableCellDirective
];

export const __PROVIDERS = [AppService];

export const __ENTRY_COMPONENTS = [ReportDetailDialogComponent];