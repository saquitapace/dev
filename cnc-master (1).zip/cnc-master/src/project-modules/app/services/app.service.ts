import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';

@Injectable()
export class AppService {

    private selectedModalSource = new Subject<any>();
    public selectedModal$ = this.selectedModalSource.asObservable();

    constructor(private httpClient: HttpClient) { }

    public getData() {
        return this.httpClient.get("./assets/data.json");
    }

    public updateSelectedModal(modalKey: string) {
        this.selectedModalSource.next(modalKey);
    }
}